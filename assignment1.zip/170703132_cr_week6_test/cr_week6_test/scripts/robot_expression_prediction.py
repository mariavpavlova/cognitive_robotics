#!/usr/bin/env python
import rospy
import random
from cr_week6_test.msg import perceived_info
from cr_week6_test.msg import robot_info
from cr_week6_test.srv import predict_robot_expression

import imp
try:
    imp.find_module('bayesian_belief_networks')
except:
    import roslib; roslib.load_manifest('bayesian_belief_networks')

from bayesian_belief_networks.ros_utils import *

#probabilities 
def f_HE(human_expression_HE):
    return 1.0/3.0
def f_HA(human_action_HA):
    return 1.0/3.0
def f_O(object_size_O):
    return 1.0/2.0

def f_RE(human_expression_HE, human_action_HA, object_size_O):
    try:
        index_re = ['happy', 'sad', 'neutral'].index(RE)
    except ValueError:
        return 0.0

    key = (human_expression_HE, human_action_HA, object_size_O)
          
#conditional probability table

    conditional_probability_table = dict()
    conditional_probability_table['small', 'happy', 'looking_r']      = [0.8, 0.2, 0.0]
    conditional_probability_table['big', 'happy', 'looking_r']        = [1.0, 0.0, 0.0]
    conditional_probability_table['small', 'happy', 'looking_o']      = [0.8, 0.2, 0.0]
    conditional_probability_table['big', 'happy', 'looking_o']        = [1.0, 0.0, 0.0]
    conditional_probability_table['small', 'happy', 'looking_away']   = [0.6, 0.2, 0.2]
    conditional_probability_table['big', 'happy', 'looking_away']     = [0.8, 0.2, 0.0]
    conditional_probability_table['small', 'sad', 'looking_r']        = [0.0, 0.0, 1.0]
    conditional_probability_table['big', 'sad', 'looking_r']          = [0.0, 0.0, 1.0]
    conditional_probability_table['small', 'sad', 'looking_o']        = [0.0, 0.1, 0.9]
    conditional_probability_table['big', 'sad', 'looking_o']          = [0.1, 0.1, 0.8]
    conditional_probability_table['small', 'sad', 'looking_away']     = [0.0, 0.2, 0.8]
    conditional_probability_table['big', 'sad', 'looking_away']       = [0.2, 0.2, 0.6]
    conditional_probability_table['small', 'neutral', 'looking_r']    = [0.7, 0.3, 0.0]
    conditional_probability_table['big', 'neutral', 'looking_r']      = [0.8, 0.2, 0.0]
    conditional_probability_table['small', 'neutral', 'looking_o']    = [0.8, 0.2, 0.0]
    conditional_probability_table['big', 'neutral', 'looking_o']      = [0.9, 0.1, 0.0]
    conditional_probability_table['small', 'neutral', 'looking_away'] = [0.6, 0.2, 0.2]
    conditional_probability_table['big', 'neutral', 'looking_away']   = [0.7, 0.2, 0.1]

    return conditional_probability_table[key][index_re]



if __name__ == "__main__":

    rospy.init_node('robot_exp_pred')
    g = ros_build_bbn(
        f_HE,
        f_HA, 
        f_O, 
        f_RE,
        domains=dict(
            HE=['happy', 'sad', 'neutral'],
            HA=['looking_r', 'looking_away', 'looking_o'],
            O=['small', 'big'],
            RE=['happy', 'sad', 'neutral']
        )
    )

    rospy.spin()
    



