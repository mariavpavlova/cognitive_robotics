#!/usr/bin/env python
import rospy
import random
from cr_week6_test.msg import object_info
from cr_week6_test.msg import human_info
from cr_week6_test.msg import perceived_info


def interaction_generator():

    #Initialise publisher
#Topics below - use in separate terminal in the end to show all topics - NB!
    objectpublisher = rospy.Publisher("ObjectInfo", object_info, queue_size=10)
    humanpublisher = rospy.Publisher("HumanInfo", human_info, queue_size=10)
    combinedpublisher = rospy.Publisher("TopicGenerate", perceived_info, queue_size=10)  

    #Generating random messages 
    rospy.init_node('interaction_generator', anonymous=True)
    rate = rospy.Rate(0.1)  

    objectmessage = object_info()
    humanmessage = human_info()
    combined_msg = perceived_info()

    id_val = 0
    while not rospy.is_shutdown():

        id_val+=1

        #Assigning values to and publishing - object,human message
        objectmessage.object_size = random.randint(1,2)
        objectmessage.id = id_val
        objectpublisher.publish(objectmessage)
        rospy.loginfo(objectmessage)

        
        humanmessage.id = id_val
        humanmessage.human_expression = random.randint(1,3)
        humanmessage.human_action = random.randint(1,3)
        humanpublisher.publish(humanmessage)
        rospy.loginfo(humanmessage)

        #overall values
        combined_msg.id = id_val
        combined_msg.object_size = objectmessage.object_size
        combined_msg.human_action = humanmessage.human_action
        combined_msg.human_expression = humanmessage.human_expression
        rospy.loginfo(combined_msg)
        combinedpublisher.publish(combined_msg)

        rate.sleep()


if __name__ == '__main__':
    try:
        interaction_generator()
    except rospy.ROSInterruptException:
        pass
