#!/usr/bin/env python

from cr_week6_test.msg import perceived_info
from cr_week6_test.msg import robot_info
from cr_week6_test.srv import predict_robot_expression
import sys
import rospy
from std_msgs.msg import Float32MultiArray

import imp; imp.find_module('bayesian_belief_networks')
from bayesian_belief_networks.ros_utils import *
from bayesian_belief_networks.msg import Observation, Result
from bayesian_belief_networks.srv import Query


human_actions = ['looking_r', 'looking_o', 'looking_away', 'None']
human_expressions = ['sad', 'happy', 'neutral', 'None']
object_sizes = ['small', 'big', 'None']


def RobotInfoMsg(msg_id, p_happy, p_sad, p_neutral):
    msg = robot_info()

    msg.id = msg_id
    msg.p_happy = p_happy
    msg.p_sad = p_sad
    msg.p_neutral = p_neutral

    return msg


#quering the service BBN

def bbnQuery(obss):
    global human_actions
    rospy.wait_for_service('{}'.format('/robot_expression_prediction/query'))
    try:
        query = rospy.ServiceProxy('/robot_expression_prediction/query', Query)
        msg = []
        if human_actions[obss.human_action] is not None:
            o = Observation()
            o.node = "HA"
            o.evidence = human_actions[obss.human_action]
            msg.append(o)
        if human_expressions[obss.human_expression] is not None:
            o = Observation()
            o.node = "HE"
            o.evidence = human_expressions[obss.human_expression]
            msg.append(o)
        if object_sizes[obss.object_size] is not None:
            o = Observation()
            o.node = "O"
            o.evidence = object_sizes[obss.object_size]
            msg.append(o)


        resp = query(msg)
        return espt.results

    except rospy.ServiceException, e:
        print "Service call failed: %s"%e



def callback(data):
    rospy.loginfo("Perceived info received with id:{}, human action:{}, human expression:{}, object size:{}".format(data.id, human_actions[data.human_action], human_expressions[data.human_expression], object_sizes[data.object_size]))
    pub = rospy.Publisher('/RobotInfo', robot_info, queue_size=10)

    results = bbnQuery(data)

    results = {r.Value: r.Marginal for r in results if r.node == 'RE'}
    print(results)
    msg = buildRobotInfoMsg(data.id, results['happy'], results['sad'], results['neutral'])
    rospy.sleep(0.1)
    pub.publish(msg)
    return




def listener():
    rospy.init_node('custom_listener', anonymous=True)
    rospy.Subscriber("PerceivedInfo", perceived_info, callback)

    rospy.spin()


if __name__ == '__main__':
    listener()


     
        
        


