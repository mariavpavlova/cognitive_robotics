#!/usr/bin/env python
import rospy
import random

from cr_week6_test.msg import object_info
from cr_week6_test.msg import human_info
from cr_week6_test.msg import perceived_info

global publisher_filter 

def callback_object(data):
    pass

def callback_human(data):
    pass

def callback_perception(data):
    
    random_filter = random.randint(1,8)
    rospy.loginfo(random_filter)
   
    if random_filter == 1:
        data.object_size = 0

    elif random_filter == 2:
        data.human_action = 0

    elif random_filter == 3:
        data.human_expression = 0

    elif random_filter == 4:
        data.object_size = 0
        data.human_action = 0

    elif random_filter == 5:
        data.object_size = 0
        data.human_expression = 0

    elif random_filter == 6:
        data.human_action = 0
        data.human_expression = 0

    elif random_filter == 7:
        data.object_size = 0
        data.human_action = 0
        data.human_expression = 0
        
    rospy.loginfo(data)
    publisher_filter.publish(data)

#Topics - use in separate terminals to show all topics - NB!
def listener():
    rospy.init_node('Perception', anonymous=True)
    rospy.Subscriber("ObjectInfo", object_info, callback_object)
    rospy.Subscriber("HumanInfo", human_info, callback_human)
    rospy.Subscriber("TopicGenerate", perceived_info, callback_perception)
    rospy.spin()

if __name__ == '__main__':
    publisher_filter = rospy.Publisher("PerceivedInfo", perceived_info, queue_size=10)
    listener()
