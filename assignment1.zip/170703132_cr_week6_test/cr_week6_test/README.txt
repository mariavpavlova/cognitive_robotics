Name: Mariya Pavlova
Student Number: 170703132

A step-by-step guide on running the package:

1. Before you run the package:
	1.1 Make sure you run the below command on every shell:
$ source /opt/ros/kinetic/setup.bash

Alternatively, you can also run: 
$ source devel/setup.bash 

You will need to run this command on every new shell you open to have access to the ROS commands, unless you add this line to your .bashrc. This process allows you to install several ROS distributions on the same computer and switch between them. 
	
	1.2 Make sure you have created a ROS workspace, i.e catkin. 
	1.3 Make sure you have created all necessary folders and saved files in their relevant folders. 
	1.4 Make sure you have updated your CMakeLists.txt and package.xml files. Otherwise, the package will not run. 
	1.5 Make sure you have roscore running in a separate terminal. 

2. Open a new terminal. In catkin_ws, type the command 'catkin_make' to build all packages.
3. Navigate to your scripts folder via the cd command. You should have four Python (.py) files there. 
4. To make these scripts executable, run the command in the scripts folder:

$ chmod +x <program name>.py 

You need to run it for all four Python files by replacing <program name> with each file's name. 

6. In a new terminal, run the .launch file via the below command. This command will run all Python scripts. No need to run them with rosrun. 

$ roslaunch cr_week6_test human_robot_interaction.launch

7. Create the ros_graph showing the nodes, topics and their connections. To do this, type the below command in a new terminal: 

$ rosrun rqt_graph rqt_graph

You should see the graph popping in a new window. 
9. Finally, we need to display four separate terminals that show the ROS Topics published by Nodes 1, 2 and 3. We can do that via the below command:

$ rostopic echo /<name of Topic>

We can find the Topics either in the Python scripts or in the graph. 
I have 5 Topics but I'm only publishing 4. I realised I had built the model in a complex way when I wasalmost done with it. Hence why I decided to stick with it due to lack of time to re-write it. 
I don't know why the 4th node (RobotInfo) doen't output anything. 
